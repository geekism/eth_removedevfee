# NoDevFee

-p: Set the port(s) for your pool. Can be separated by ",". For Example: -p 4444,14444

-w: wallet address. For example: -w 0xdeadbeef1234. If no walletaddress is passed it will try to read the address from "wallet.txt" file

-s: searchpattern, defaults to "eth_submitLogin"

For educational purpose only
